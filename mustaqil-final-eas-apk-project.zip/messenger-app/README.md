# مستقل — دليل الإنتاج النهائي

**اسم التطبيق:** مستقل
**المطور ومالك المشروع:** ماجد بن محمد
**Package Name:** `com.majidbinmohammed.mustaqil`
**حقوق الملكية:** © 2026 ماجد بن محمد — جميع الحقوق محفوظة.

هذا المشروع يحتوي على Backend وعميل Expo Android. لا يحتوي المستودع على أسرار أو مفاتيح إنتاج.

## الحالة بوضوح

تم اختبار Backend محليًا مع SQLite، JWT، المستخدمين، المحادثات، الرسائل، WebSocket، المجموعات، الحالات، الخصوصية، الحظر، التقارير، رفع الملفات المحلي، قفل PIN والبصمة على مستوى كود الهاتف.

تم تجهيز مخطط PostgreSQL وأداة نقل SQLite، وS3-compatible adapter، وFirebase Admin service، وDocker Compose، وWebRTC signaling. لم يتم تنفيذ نقل فعلي إلى قاعدة خارجية أو نشر دائم أو اختبار جهازين حقيقيين أو بناء APK في هذه البيئة، لأن PostgreSQL/Docker/Android SDK/EAS credentials وخدمات Firebase/S3/TURN غير متاحة هنا. لذلك لا يُسمى المشروع Production Ready قبل تنفيذ خطوات الإعداد أدناه.

## تشغيل التطوير المحلي

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

ثم:

```bash
cd mobile
npm install
npx expo start
```

عند الاختبار من هاتف حقيقي، اضبط `EXPO_PUBLIC_API_URL` على عنوان HTTPS أو عنوان الشبكة الذي يمكن للهاتف الوصول إليه؛ لا تستخدم `localhost`.

## PostgreSQL

أنشئ قاعدة PostgreSQL ثم انسخ `backend/.env.production.example` إلى `backend/.env.production` واضبط `DATABASE_URL` و`JWT_SECRET`. لإنشاء الجداول:

```bash
psql "$DATABASE_URL" -f backend/postgres/schema.sql
```

لنقل بيانات SQLite الموجودة:

```bash
cd backend
SQLITE_SOURCE=./data/messenger.db DATABASE_URL='postgresql://...' npm run migrate:postgres
```

المهاجر ينقل الجداول والعلاقات والرسائل والوسائط والإعدادات ولا يحذف مصدر SQLite. نفّذه أولًا على نسخة احتياطية واختبر عدد الصفوف قبل تحويل التطبيق.

> ملاحظة مهمة: خادم المرحلة الحالية يستخدم SQLite افتراضيًا للحفاظ على التشغيل المحلي. بعد توفير PostgreSQL يجب تنفيذ طبقة runtime PostgreSQL والتحقق منها قبل تحويل `DATABASE_DRIVER` في الإنتاج؛ لا تضع `DATABASE_URL` وحده وتفترض أن الخادم انتقل تلقائيًا.

## Object Storage

يمكن استخدام Cloudflare R2 أو Amazon S3 أو أي S3-compatible provider. اضبط `S3_BUCKET`, `S3_REGION`, `S3_ENDPOINT`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY` و`S3_FORCE_PATH_STYLE` من Secret Manager. عند توفرها يستخدم الخادم S3 ويعيد رابط GET موقعًا لمدة 15 دقيقة. في غيابها يعود إلى التخزين القرصي المحلي للتطوير فقط.

## Push Notifications

أنشئ Firebase project، فعّل Cloud Messaging، وأنشئ Service Account. خزّن JSON كاملًا في `FIREBASE_SERVICE_ACCOUNT_JSON` كسر في بيئة الخادم. التطبيق يطلب الإذن ويسجل Expo Push Token عبر `/api/v1/devices/push-token`، والخادم يستدعي Firebase عند وصول رسالة. يجب ضبط Android notification channel وملف Firebase/credentials ضمن EAS أو development build وفق مزود البناء.

## WebRTC وTURN/STUN

أحداث signaling موجودة عبر WebSocket (`call.offer`, `call.answer`, `call.ice`, `call.end`). لإكمال المكالمات فعليًا يجب إضافة عميل WebRTC native/dev-client، إعداد TURN مثل coturn أو مزود موثوق، وضبط `TURN_URL`, `TURN_USERNAME`, `TURN_CREDENTIAL`. يجب اختبار مكالمة صوت وفيديو بين هاتفين على شبكتين مختلفتين؛ لا تُعتبر المكالمات مكتملة قبل هذا الاختبار.

## نشر Backend دائم

الطريقة المرفقة هي Docker Compose على VPS أو مزود حاويات:

```bash
cp backend/.env.production.example backend/.env.production
# عبّئ الأسرار من Secret Manager
export POSTGRES_PASSWORD='strong-password-from-secret-manager'
docker compose -f docker-compose.production.yml up -d --build
```

ضع Caddy أو Nginx أمام المنفذ 4000 لإصدار HTTPS، واسمح فقط بالمنافذ 80 و443، ولا تعرض PostgreSQL للعامة. فعّل النسخ الاحتياطي والمراقبة وتدوير الأسرار وCORS بنطاق التطبيق فقط.

## بناء APK/AAB

### من جهاز به EAS

```bash
cd mobile
npm install
npx eas login
npx eas build:configure
EXPO_PUBLIC_API_URL=https://api.example.com npx eas build --platform android --profile preview
EXPO_PUBLIC_API_URL=https://api.example.com npx eas build --platform android --profile production
```

للنشر على Google Play استخدم AAB من profile production. يحتاج EAS project وcredentials وFirebase/Android configuration.

### من الهاتف فقط

أسهل مسار هو استخدام Expo Snack أو GitHub Codespaces من متصفح الهاتف: ارفع مجلد `mobile` إلى مستودع خاص، افتح المشروع في Codespaces، ثبّت Node ثم شغّل أوامر EAS السابقة من Terminal المتصفح، وبعد انتهاء البناء نزّل رابط APK إلى الهاتف. لا يمكن إنشاء APK محليًا من Expo Go وحده؛ Expo Go يشغل JavaScript ولا يبني APK مستقلًا.

## اختبار جهازين

1. شغّل Backend على HTTPS دائم.
2. اضبط `EXPO_PUBLIC_API_URL` نفسه في build الهاتفين.
3. أنشئ حساب A وحساب B برقمين مختلفين.
4. ابحث عن B من A وأنشئ محادثة.
5. أرسل رسالة نصية وملفًا وتحقق من وصول WebSocket.
6. اختبر المجموعة والحالة والخصوصية والحظر والتقرير.
7. اختبر Push والتطبيق في الخلفية.
8. اختبر PIN والبصمة.
9. اختبر المكالمة الصوتية والفيديو على شبكتين مختلفتين بعد إعداد TURN.

## أوامر التحقق

```bash
cd backend
npm run typecheck
npm run build
npm test
npm run migrate:postgres  # يتطلب DATABASE_URL وSQLITE_SOURCE عند التنفيذ الفعلي

cd ../mobile
npm run typecheck
npx expo config --type public --json
```

## حقوق المشروع

© 2026 ماجد بن محمد — جميع الحقوق محفوظة.

لا يدّعي المشروع تسجيل علامة تجارية أو براءة اختراع أو حماية حكومية غير مسجلة فعليًا. يجب احترام تراخيص كل مكتبة أو خدمة خارجية.
