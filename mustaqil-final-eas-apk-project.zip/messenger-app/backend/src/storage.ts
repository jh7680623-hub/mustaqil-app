import fs from 'node:fs/promises';
import path from 'node:path';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const bucket=process.env.S3_BUCKET;
const endpoint=process.env.S3_ENDPOINT;
const s3=bucket ? new S3Client({region:process.env.S3_REGION||'auto',endpoint,forcePathStyle:process.env.S3_FORCE_PATH_STYLE==='true',credentials:process.env.S3_ACCESS_KEY_ID&&process.env.S3_SECRET_ACCESS_KEY?{accessKeyId:process.env.S3_ACCESS_KEY_ID,secretAccessKey:process.env.S3_SECRET_ACCESS_KEY}:undefined}) : null;
export async function persistUpload(file:{path:string;mimeType:string;key:string}) {
  if(s3 && bucket){const body=await fs.readFile(file.path);await s3.send(new PutObjectCommand({Bucket:bucket,Key:file.key,Body:body,ContentType:file.mimeType}));await fs.rm(file.path,{force:true});return {storagePath:file.key,url:await getSignedUrl(s3,new GetObjectCommand({Bucket:bucket,Key:file.key}),{expiresIn:900})};}
  return {storagePath:file.path,url:`/uploads/${path.basename(file.path)}`};
}
export const storageMode=()=>s3&&bucket?'s3-compatible':'local-disk';
