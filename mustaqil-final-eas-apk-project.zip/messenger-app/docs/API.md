# API v1

Base URL: `/api/v1`

## Authentication

- `POST /auth/register` body `{ phone, username, password, displayName }` → `{ token, user }`
- `POST /auth/login` body `{ phone, password }` → `{ token, user }`
- `POST /auth/logout` Authorization Bearer token
- `GET /me` Authorization Bearer token

## Users and chats

- `GET /users?q=` search by username/display name
- `POST /chats/direct` body `{ userId }`
- `GET /chats`
- `GET /chats/:chatId/messages?limit=50&before=`
- `POST /chats/:chatId/messages` body `{ body, type?, mediaUrl?, replyToId? }`

## WebSocket

Connect to `ws(s)://host/ws?token=JWT`. The server emits:

```json
{ "type": "message.new", "message": { "id": "...", "chatId": "...", "senderId": "...", "body": "..." } }
```

## الميزات الممتدة

- `POST /media` multipart `file`، بحد 50MB في التطوير، ويعيد سجل وسائط ورابط `/uploads/...`.
- `POST /groups` body `{ title, memberIds[] }`.
- `POST /groups/:chatId/members`، `DELETE /groups/:chatId/members/:userId`، و`PATCH /groups/:chatId/members/:userId/role` للمشرفين.
- `POST /stories`، `GET /stories`، `POST /stories/:storyId/view`، و`DELETE /stories/:storyId`.
- `GET/PATCH /privacy` لإعدادات آخر ظهور والصورة والحالات وإيصالات القراءة والظهور online.
- `GET /blocked-users`، `POST/DELETE /blocked-users/:userId`، و`POST /reports`.
- `POST /devices/push-token` لتسجيل Expo/FCM token؛ إرسال Push يحتاج مفاتيح FCM/APNs في بيئة النشر.
- `PUT/DELETE /chats/:chatId/lock` و`POST /chats/:chatId/lock/verify`؛ الـPIN يُخزّن مجزأً.

## WebRTC signaling

يدعم WebSocket أحداث `call.offer`, `call.answer`, `call.ice`, و`call.end` مع `toUserId` و`payload` لترحيل signaling فقط. نقل الصوت والفيديو نفسه يحتاج WebRTC client وTURN/STUN ولم يُعلن كمكتمل.

تتحقق المسارات من عضوية المستخدم قبل قراءة أو كتابة بيانات المحادثة. يجب استخدام HTTPS/WSS وPostgreSQL/Object Storage مُدارين في الإنتاج.
