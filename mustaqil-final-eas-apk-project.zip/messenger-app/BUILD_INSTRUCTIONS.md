# تعليمات نقل وبناء تطبيق مستقل عبر Expo EAS

**اسم التطبيق:** مستقل  
**Package Name:** `com.majidbinmohammed.mustaqil`  
**Profile:** `preview` — Android APK  
**Expo SDK:** `~52.0.18`

## 1. نقل المشروع

انقل مجلد المشروع كاملًا إلى البيئة الخارجية، مع الحفاظ على المجلدات التالية:

- `mobile/app.json`
- `mobile/eas.json`
- `mobile/package.json`
- `mobile/package-lock.json`
- `mobile/App.tsx`

ثم نفّذ:

```bash
cd mobile
npm ci
```

## 2. التحقق من إعدادات Android

يجب أن تبقى القيم التالية كما هي:

```text
اسم التطبيق: مستقل
Package Name: com.majidbinmohammed.mustaqil
```

ويجب أن يبقى `mobile/eas.json` يحتوي على:

```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" }
    }
  }
}
```

## 3. ربط المشروع بمشروع EAS الموجود

استخدم مشروع EAS الموجود للتطبيق الحالي فقط. لا تنشئ مشروعًا جديدًا.

يجب أن يحتوي `mobile/app.json` على معرّف المشروع الموجود تحت:

```json
{
  "expo": {
    "extra": {
      "eas": {
        "projectId": "EXISTING_EAS_PROJECT_ID"
      }
    }
  }
}
```

استبدل `EXISTING_EAS_PROJECT_ID` بالـ`projectId` الحقيقي للمشروع الموجود فقط. لا تخمّن القيمة ولا تستخدم معرّف مشروع آخر.

## 4. المصادقة الآمنة

ضع Expo Personal Access Token في Secret Manager أو في Secrets الخاصة ببيئة CI باسم:

```text
EXPO_TOKEN
```

لا تضع قيمة الرمز داخل الكود أو ملفات المشروع أو GitHub workflow أو رسائل السجل. لا تكتب الرمز في هذا الملف.

بعد حقن المتغير من Secret Manager، تحقق من الحساب:

```bash
npx eas-cli@latest whoami
```

## 5. بناء Android Preview APK

من مجلد `mobile` نفّذ الأمر التالي:

```bash
npx eas-cli@latest build --platform android --profile preview
```

لبيئة CI غير التفاعلية استخدم:

```bash
npx eas-cli@latest build --platform android --profile preview --non-interactive
```

سيكون الناتج APK قابلًا للتثبيت مباشرة على Android لأن `preview.android.buildType` مضبوط على `apk`.

## 6. التحقق بعد البناء

بعد انتهاء EAS، افتح رابط البناء الذي يعرضه الأمر، ثم نزّل ملف APK من صفحة البناء. تحقق من أن Package Name هو:

```text
com.majidbinmohammed.mustaqil
```

هذه التعليمات لا تنفّذ ربطًا أو Build تلقائيًا، ولا تحتوي على أي Token أو Secret.
