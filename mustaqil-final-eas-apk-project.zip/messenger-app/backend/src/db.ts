import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';

const dbPath = process.env.DATABASE_PATH || path.join(process.cwd(), 'data', 'messenger.db');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, phone TEXT UNIQUE NOT NULL, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS profiles (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 display_name TEXT NOT NULL, avatar_url TEXT, about TEXT NOT NULL DEFAULT '',
 locale TEXT NOT NULL DEFAULT 'ar', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 token_jti TEXT UNIQUE NOT NULL, device_name TEXT, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('direct','group')),
 title TEXT, created_by TEXT REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_members (
 chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL DEFAULT 'member', joined_at TEXT NOT NULL,
 PRIMARY KEY(chat_id,user_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 sender_id TEXT NOT NULL REFERENCES users(id), type TEXT NOT NULL DEFAULT 'text',
 body TEXT NOT NULL, media_url TEXT, reply_to_id TEXT REFERENCES messages(id),
 created_at TEXT NOT NULL, edited_at TEXT, deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS message_status (
 message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('sent','delivered','read')), updated_at TEXT NOT NULL,
 PRIMARY KEY(message_id,user_id)
);
CREATE TABLE IF NOT EXISTS contacts (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 contact_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(user_id,contact_user_id)
);
CREATE TABLE IF NOT EXISTS blocked_users (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 blocked_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(user_id,blocked_user_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_chat_created ON messages(chat_id,created_at);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
`);

db.exec(`
CREATE TABLE IF NOT EXISTS media (
 id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 original_name TEXT NOT NULL, mime_type TEXT NOT NULL, size INTEGER NOT NULL,
 storage_path TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stories (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL CHECK(type IN ('text','image','video')), body TEXT NOT NULL,
 media_url TEXT, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS story_views (
 story_id TEXT NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
 viewer_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, viewed_at TEXT NOT NULL,
 PRIMARY KEY(story_id,viewer_id)
);
CREATE TABLE IF NOT EXISTS privacy_settings (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 last_seen TEXT NOT NULL DEFAULT 'everyone', profile_photo TEXT NOT NULL DEFAULT 'everyone',
 about TEXT NOT NULL DEFAULT 'everyone', stories TEXT NOT NULL DEFAULT 'contacts', read_receipts INTEGER NOT NULL DEFAULT 1,
 online_status INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS reports (
 id TEXT PRIMARY KEY, reporter_id TEXT NOT NULL REFERENCES users(id), reported_user_id TEXT NOT NULL REFERENCES users(id),
 reason TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS device_tokens (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 token TEXT UNIQUE NOT NULL, platform TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_locks (
 chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, pin_hash TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(chat_id,user_id)
);
`);

export type UserRow = { id:string; phone:string; username:string; password_hash:string; created_at:string; updated_at:string; is_active:number };
export type ProfileRow = { user_id:string; display_name:string; avatar_url:string|null; about:string; locale:string };
export const now = () => new Date().toISOString();
export const publicUser = (u: UserRow, p?: ProfileRow) => ({ id:u.id, phone:u.phone, username:u.username, displayName:p?.display_name ?? u.username, avatarUrl:p?.avatar_url ?? null, about:p?.about ?? '', locale:p?.locale ?? 'ar', createdAt:u.created_at });
