import 'dotenv/config';
import Database from 'better-sqlite3';
import { Pool } from 'pg';
import fs from 'node:fs';
import path from 'node:path';

const url=process.env.DATABASE_URL;if(!url)throw new Error('DATABASE_URL is required');
const sqlitePath=process.env.SQLITE_SOURCE||path.join(process.cwd(),'data','messenger.db');
if(!fs.existsSync(sqlitePath))throw new Error(`SQLite source not found: ${sqlitePath}`);
const sqlite=new Database(sqlitePath,{readonly:true});const pool=new Pool({connectionString:url});
const tables=['users','profiles','sessions','chats','chat_members','messages','message_status','contacts','blocked_users','media','stories','story_views','privacy_settings','reports','device_tokens','chat_locks'];
const boolTables=new Set(['users.is_active','privacy_settings.read_receipts','privacy_settings.online_status']);
function columns(table:string){return (sqlite.prepare(`PRAGMA table_info(${table})`).all() as {name:string}[]).map(x=>x.name)}
(async()=>{const client=await pool.connect();try{await client.query('BEGIN');await client.query(fs.readFileSync(path.join(process.cwd(),'postgres','schema.sql'),'utf8'));for(const table of tables){const cols=columns(table);const rows=sqlite.prepare(`SELECT ${cols.join(',')} FROM ${table}`).all() as any[];for(const row of rows){const values=cols.map(c=>{const key=`${table}.${c}`;if(boolTables.has(key))return !!row[c];return row[c]});const placeholders=values.map((_,i)=>`$${i+1}`).join(',');await client.query(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,values);}}await client.query('COMMIT');console.log(`Migrated ${tables.length} tables from ${sqlitePath}`);}catch(e){await client.query('ROLLBACK');throw e}finally{client.release();await pool.end()}})().catch(e=>{console.error(e);process.exit(1)});
