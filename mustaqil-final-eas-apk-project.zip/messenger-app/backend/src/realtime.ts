import { WebSocket } from 'ws';
const sockets = new Map<string, Set<WebSocket>>();
export function addSocket(userId:string, socket:WebSocket) { if (!sockets.has(userId)) sockets.set(userId,new Set()); sockets.get(userId)!.add(socket); socket.on('close',()=>sockets.get(userId)?.delete(socket)); }
export function emitToUsers(userIds:string[], payload:unknown) { const data=JSON.stringify(payload); for (const id of userIds) for (const socket of sockets.get(id) ?? []) if (socket.readyState===WebSocket.OPEN) socket.send(data); }
export function onlineUsers() { return [...sockets.entries()].filter(([,s])=>s.size>0).map(([id])=>id); }
