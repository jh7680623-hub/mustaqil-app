# خطة الإنتاج والتسليم

## ما تم التحقق منه داخل Sandbox

نجح `npm test` و`npm run typecheck` و`npm run build` للـBackend، ونجح `npm run typecheck` و`expo config` لتطبيق Android. تم اختبار التسجيل، JWT، قاعدة SQLite، المحادثات، الرسائل، WebSocket، المجموعات، الحالات، الخصوصية، الحظر، PIN، ورفع ملف محلي. لم يتم اختبار Firebase أو S3 أو PostgreSQL أو TURN أو جهازين حقيقيين لأن حسابات وخدمات الإنتاج غير متاحة.

## PostgreSQL

استخدم `backend/postgres/schema.sql` لإنشاء الجداول، ثم نفّذ `npm run migrate:postgres` مع `DATABASE_URL` و`SQLITE_SOURCE` لنقل البيانات. أداة النقل لا تحذف SQLite. خادم runtime الحالي ما زال SQLite افتراضيًا؛ يجب تطبيق طبقة PostgreSQL runtime والتحقق من جميع الاستعلامات قبل إعلان الانتقال مكتملًا.

## Object Storage

يستخدم `backend/src/storage.ts` S3-compatible عند ضبط متغيرات S3، ويرجع رابط GET موقّعًا لمدة قصيرة. من دونها يستخدم القرص المحلي للتطوير فقط. لا تشارك مفاتيح S3 مع تطبيق الهاتف.

## Push

يستخدم `backend/src/push.ts` Firebase Admin عند ضبط `FIREBASE_SERVICE_ACCOUNT_JSON`. يجب إنشاء Firebase project وFCM credentials وAndroid notification configuration، ثم اختبار رسالة في الخلفية على جهاز فعلي.

## WebRTC

WebSocket signaling فقط موجود. الإكمال يتطلب `react-native-webrtc` عبر Expo development build، TURN/STUN، تبادل ICE فعلي، واختبار صوت وفيديو بين هاتفين على شبكتين مختلفتين. لا تُعتبر المكالمات مكتملة الآن.

## HTTPS والنشر الدائم

`backend/Dockerfile` و`docker-compose.production.yml` يجهزان Backend وPostgreSQL. شغّلهما على VPS أو خدمة حاويات مع Caddy/Nginx أمام المنفذ 4000، واحتفظ بـPostgreSQL داخليًا، واضبط النسخ الاحتياطي والمراقبة وCORS وrate limiting وSecret Manager.

## APK/AAB

لا يوجد APK أو AAB مبني في Sandbox: `adb`, `sdkmanager`, `eas` وAndroid SDK غير متاحة. استخدم EAS من جهاز أو Codespace متصل بالإنترنت، كما هو موضح في README. Expo Go لا ينتج APK مستقلًا.
