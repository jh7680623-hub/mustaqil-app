import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';
import { db } from './db';
let ready=false;
function ensure(){if(ready)return true;const json=process.env.FIREBASE_SERVICE_ACCOUNT_JSON;if(!json)return false;try{if(!getApps().length)initializeApp({credential:cert(JSON.parse(json))});ready=true;return true;}catch(e){console.error('Firebase initialization failed',e);return false;}}
export async function notifyUser(userId:string,title:string,body:string,data:Record<string,string>={}){if(!ensure())return {sent:false,reason:'FIREBASE_SERVICE_ACCOUNT_JSON not configured'};const rows=db.prepare('SELECT token FROM device_tokens WHERE user_id=?').all(userId) as {token:string}[];if(!rows.length)return {sent:false,reason:'no device token'};const result=await getMessaging().sendEachForMulticast({tokens:rows.map(x=>x.token),notification:{title,body},data});return {sent:true,successCount:result.successCount,failureCount:result.failureCount};}
