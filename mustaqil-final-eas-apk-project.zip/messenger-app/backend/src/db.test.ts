import test from 'node:test';
import assert from 'node:assert/strict';
import { db } from './db';

test('database schema contains core real-time messaging tables', () => {
  const names = (db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all() as {name:string}[]).map(x=>x.name);
  for (const table of ['users','profiles','sessions','chats','chat_members','messages','message_status']) assert.ok(names.includes(table), table);
});
