import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { db, now } from './db';

const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
export const hashPassword = (password:string) => bcrypt.hash(password, 12);
export const verifyPassword = (password:string, hash:string) => bcrypt.compare(password, hash);
export type Claims = { sub:string; jti:string; username:string };
export function issueToken(userId:string, username:string) {
  const jti = crypto.randomUUID();
  const token = jwt.sign({ sub:userId, jti, username }, secret!, { expiresIn:'30d' });
  db.prepare('INSERT INTO sessions(id,user_id,token_jti,device_name,expires_at,created_at) VALUES (?,?,?,?,?,?)')
    .run(crypto.randomUUID(), userId, jti, 'mobile', new Date(Date.now()+30*86400000).toISOString(), now());
  return token;
}
export function readToken(token:string): Claims {
  const decoded = jwt.verify(token, secret!) as Claims;
  const active = db.prepare('SELECT id FROM sessions WHERE user_id=? AND token_jti=? AND expires_at>?').get(decoded.sub, decoded.jti, now());
  if (!active) throw new Error('Session expired');
  return decoded;
}
export function revokeToken(token:string) { const c = jwt.decode(token) as Claims|null; if (c?.jti) db.prepare('DELETE FROM sessions WHERE token_jti=?').run(c.jti); }
